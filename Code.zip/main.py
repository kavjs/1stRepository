print("Welcome! This is a basic, training and diet plan generator!")
dummy = ''
part = '_'
def separator(n):
  for i in range(0,n):
    print(part, end='')
    i = i+1
  print()
  return dummy
print(separator(59))
print("Enter your body weight, age, and height respectively (only numbers)")
print(separator(59))
bodyWeight = int(input("Bodyweight in pounds: "))
print(separator(21))
heightFeet = int(input("Feet: "))
print(separator(5))
heightInches = int(input("Inches: "))
print(separator(7))
age = int(input("Enter your age: "))
print(separator(7))
heightUse = (heightFeet*12) + heightInches
bodyMassIndex = (bodyWeight/(heightUse**2))*703
print("Your BMI is ", round(bodyMassIndex, 1))
print(separator(11))
def bmiHealthy(bodyMassIndex):
  if bodyMassIndex < 18.5:
     print("You are Underweight")
     print(separator(19))
     print()
  elif 18.5 <= bodyMassIndex <= 24.9:
     print("You are at a Healthy Weight")
     print(separator(27))
     print()
  elif bodyMassIndex > 24.9 and bodyMassIndex <= 29.9:
     print("You are Overweight")
     print(separator(18))
     print()
  elif bodyMassIndex > 29.9:
     print("You are Obese")
     print(separator(13))
     print()
  return dummy
print(bmiHealthy(bodyMassIndex))
print("Choose which Muscle Group you would like to improve!")
print(separator(59))
print("Note: You will have to track your caloric intake!")
print()
print("To lose weight burn more calories than you eat!")
print()
print("To gain weight eat more than you burn! Use MyFitnessPal to track calories!")
print(separator(59))
print()
list1 = ["Upper Body|", "Back Muscles|", "Lower Body|", "Full Body (Endurance)|"]
for count, ele in enumerate(list1, 1):
  print('|', count,'.', ele,' ', end='')
print()
print()
muscleGroup = int(input("Choose 1, 2, 3, or 4: "))
print(separator(59))
if muscleGroup == 1:
    print("Do the following for 3 Sets 3x a Week: ")
    print(separator(59))
    print("-Barbell Bench Press For 5 Repetitions: ",round(bodyWeight*0.47), "lbs" )
    print( )
    print("-Dumbbell Bent Over Row for 4 Repetitions: ",round(bodyWeight*0.1), "lbs" )
    print()
    print("-Lat Pulldown 8 Repetitions: ",round(bodyWeight/4), "lbs" )
    print()
    print("-Arnold Dumbbell Press 6 Repetitions: ", round(bodyWeight/10), "lbs")
    print()
    print("-Push Press 4 Repetitions: ",round(bodyWeight*(3.5/12)), "lbs" )
    print()
    print("-Dumbbell Skullcrusher 6 Repetitions: ",5, "lbs" )
    print()
    print("-Barbell Curl 6 Repetitions: ",round(bodyWeight/10), "lbs" )
    print(separator(59))
elif muscleGroup == 2:
  print("Do the following for 3 Sets 3x a Week: ")
  print(separator(59))
  print("-Pull-Ups Assisted w/Band or Without 5 Repetitions")
  print()
  print("-Deadlift 4 Repetitions: ",round(bodyWeight*0.76), "lbs")
  print()
  print("-Cable Rows 6 Repetitions: ",round(bodyWeight*0.45), "lbs")
  print()
  print("-Lat Pulldown 8 Repetitions: ",round(bodyWeight/4), "lbs" )
  print()
  print("-Back Extensions 6 Repetitions")
  print()
  print("-Superman 4 Repetitions")
  print(separator(59))
elif muscleGroup == 3:
  print("Do the following for 3 Sets 3x a Week: ")
  print(separator(59))
  print("-Squats Goblet, Front, or Back for 6 Repetitions",round(bodyWeight*0.6), "lbs")
  print()
  print("-Lunges 4 Repetitions Each Leg: 10 lbs each arm")
  print()
  print("-Step-Ups 6 Each Leg (Use a Gym Stool)")
  print()
  print("-Hip Thrusts 8 Repetitions: ",round(bodyWeight*0.45), "lbs")
  print()
  print("-Calf Raises 10 Repetitions (Wall can be used for Assist)")
  print()
  print("-Bridges 15 Second hold")
  print(separator(59))
elif muscleGroup == 4:
  print("Do the following for 3 Sets 3x a Week: ")
  print(separator(59))
  print("WARMUP: 5-Minute Jog, Moving Lunges, Arm Circles, and Heel-To-Toe")
  print(separator(59))
  print("Strength Circuit: Do for 3 sets ")
  print(separator(59))
  print("-Dumbbell Bent Over Row for 4 Repetitions: ",round(bodyWeight*0.1), "lbs" )
  print()
  print("-Dumbell Shoulder Press 10 Lbs 6 Repetitions")
  print()
  print("-Bodyweight Squats 6 Repetitions")
  print()
  print("-Push-Ups (Or Modified) 6 Repetitions")
  print()
  print("-Bodyweight Lunges 6 Repetitions")
  print()
  print("-Plank for 15 Seconds")
  print()
  print(separator(59))
  print("Interval Circuit: Do 4 times")
  print(separator(59))
  print("High Intensity: 30 Second Sprinting")
  print()
  print("Low Intensity: 40 second Jogging or Walking")
print(separator(59))
print("You can increase Repetitons as needed and lower starting weight by 5 lbs Max")
print()
print("Round the weights to the nearest multiple of 5!")
print(separator(59))
gender = str(input("Enter Your Gender as F or M; or which one you are prominently: "))
print(separator(59))
bmr = 0
if gender == "F":
  bmr = 655 + (4.35*bodyWeight) + (4.7* heightUse) - (4.7*age)
elif gender == "M":
  bmr = 66 + (6.23* bodyWeight) + (12.7* heightUse) - (6.8*age)
print("How many times per week do you exercise:")
print(" ")
list3 = ["Less than 3|","3-5|","5+|"]
for cnt, ele in enumerate(list3):
  print('|', cnt + 1,'.', ele,' ', end='')
activityLevel = int(input("Choose 1, 2, or 3: "))
print(separator(59))
if activityLevel == 1:
  activityFactor = 1.35
elif activityLevel == 2:
  activityFactor = 1.65
elif activityLevel == 3:
  activityFactor = 1.9
option = str(input("Do you want to lose or gain weight? Answer L or G in Capital: "))
if option == "L":
  tdee = bmr * activityFactor
  intake = tdee - 500
  perMeal = round(intake/3, -1)
elif option == "G":
  tdee = bmr * activityFactor
  intake = tdee + 500
  perMeal = round(intake/3, -1)
print(separator(59))
print("Eat",perMeal, "calories per meal!")
print(separator(59))
print("The following is the nutrient break down that you should get in a day!")
print("")
protein = intake*0.25
carbs = intake*0.55
fats = intake*0.20
print("Protein intake: ", round(protein, -1),"Calories")
print(round(protein/4,-1), "Grams of Protein")
print("")
print("Complex Carbs: ", round(carbs,-1), "Calories")
print(round(carbs/4,-1), "Grams of Complex Carbs")
print("")
print("Healthy Fats: ", round(fats,-1), "Calories")
print(round(fats/9,-1),"Grams of Fat")
print(separator(60))
print("The key is consistency and planning! Track how much you eat on a spreadsheet!")